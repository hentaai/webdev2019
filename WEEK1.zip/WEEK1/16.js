const plantNeedsWater = function(day) {
  if (day === 'Wednesday') {
    return true;
  } else {
    return false;
  }
};

const plantNeedsWater = (day) =>{
  if (day === 'Wednesday'){
    return true;
  }
  else{
    return true
  }
}