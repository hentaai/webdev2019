
const plantNeedsWater = day => day === 'Wednesday' ? true:false