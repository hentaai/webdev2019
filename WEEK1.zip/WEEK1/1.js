let sale = true
sale = false
if (sale){
	console.log('Time to buy!')
}


